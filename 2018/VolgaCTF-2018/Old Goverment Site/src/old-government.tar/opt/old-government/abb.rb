require 'sinatra'
require "open-uri"
require 'openssl'
require 'open_uri_redirections'

set :bind, '0.0.0.0'
set :port, 8080


OpenSSL::SSL::VERIFY_PEER = OpenSSL::SSL::VERIFY_NONE

  get '/' do
        page = params[:page]
    headers "Server" => ""
        erb :index
  end

  get '/page' do
        @id = params[:id]
    headers "Server" => ""
        erb :articles
  end

  post '/page' do
        @id = params[:id]
    headers "Server" => ""
        erb :articles
  end



  def siteValidator(site)
    begin
          r = open(site, :allow_redirections => :all)
          "validated"
    rescue Exception => e
          "error"
    end

  end