window.admin = {
  id: 'admin'
}
window.banword = 'give me flag'
