# MortAl mage aGEnts
## deploy
```
docker-compose up -d
```
## issue
### Chrome Headless fails due to sandbox issues
https://github.com/GoogleChrome/puppeteer/blob/master/docs/troubleshooting.md#chrome-headless-fails-due-to-sandbox-issues
